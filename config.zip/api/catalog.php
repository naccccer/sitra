<?php
declare(strict_types=1);

require_once __DIR__ . '/modules/master_data/catalog.php';

