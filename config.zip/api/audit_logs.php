<?php
declare(strict_types=1);

require_once __DIR__ . '/modules/kernel/audit_logs.php';
