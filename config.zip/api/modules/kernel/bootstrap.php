<?php
declare(strict_types=1);

require_once __DIR__ . '/../../_common.php';
require_once __DIR__ . '/../../../config/db.php';
require_once __DIR__ . '/../../kernel/ModuleGuard.php';

app_handle_preflight(['GET']);
app_require_method(['GET']);

$user = null;
try {
    $user = app_current_user();
} catch (Throwable $e) {
    $user = null;
}

$catalog = null;
try {
    $catalog = app_read_catalog($pdo);
} catch (Throwable $e) {
    $catalog = null;
}

$profile = null;
try {
    $profile = app_read_profile($pdo);
} catch (Throwable $e) {
    $profile = app_profile_defaults();
}

$role = $user['role'] ?? null;
$modules = app_module_registry($pdo);
$isOwner = app_kernel_is_owner($user);
$permissions = app_permissions_without_kernel_control(app_role_permissions((string)$role, $pdo));
$capabilities = app_module_capabilities($role, $modules, $pdo);
$capabilities['canManageSystemSettings'] = $isOwner;
$csrfToken = app_csrf_token();
app_release_session_lock();

// Load only the 50 most recent orders to keep bootstrap fast.
// The frontend can load more on demand via GET /api/orders.php?cursor=<id>.
$BOOTSTRAP_LIMIT = 50;
$ordersItems = [];
$ordersTotal = 0;
$ordersHasMore = false;
$ordersNextCursor = null;

if ($user !== null) {
    try {
        app_ensure_orders_table($pdo);

        $fetchLimit = $BOOTSTRAP_LIMIT + 1;
        $stmt = $pdo->query(
            'SELECT ' . app_orders_select_fields($pdo) .
            ', COUNT(*) OVER() AS _total_count' .
            ' FROM orders ORDER BY id DESC LIMIT ' . $fetchLimit
        );
        $rows = $stmt ? $stmt->fetchAll() : [];

        $ordersTotal = count($rows) > 0 ? (int)$rows[0]['_total_count'] : 0;

        $ordersHasMore = count($rows) > $BOOTSTRAP_LIMIT;
        if ($ordersHasMore) {
            array_pop($rows);
        }

        // Pass null for $pdo to skip per-order financials/payments queries.
        // Bootstrap returns lightweight orders with defaults derived from
        // the orders.total column.  Full hydration (financials + payments)
        // is provided by GET /api/orders.php.
        foreach ($rows as $row) {
            $ordersItems[] = app_order_from_row($row);
        }

        if ($ordersHasMore && count($ordersItems) > 0) {
            $lastOrder = end($ordersItems);
            $ordersNextCursor = (string)($lastOrder['id'] ?? '');
        }
    } catch (Throwable $e) {
        $ordersItems = [];
    }
}

$response = [
    'success' => true,
    'session' => [
        'authenticated' => $user !== null,
        'role' => $role,
        'username' => $user['username'] ?? null,
        'fullName' => ($user !== null && trim((string)($user['fullName'] ?? '')) !== '')
            ? (string)$user['fullName']
            : ($user['username'] ?? null),
        'jobTitle' => ($user !== null && trim((string)($user['jobTitle'] ?? '')) !== '')
            ? (string)$user['jobTitle']
            : null,
    ],
    'permissions' => $permissions,
    'capabilities' => $capabilities,
    'csrfToken' => $csrfToken,
    'catalog' => $catalog,
    'profile' => $profile,
    'orders' => [
        'items' => $ordersItems,
        'total' => $ordersTotal,
        'hasMore' => $ordersHasMore,
        'nextCursor' => $ordersNextCursor,
    ],
];

if ($isOwner) {
    $response['modules'] = $modules;
}

app_json($response);
